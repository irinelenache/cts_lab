package cts.Enache.IrinelMihaita.g1080.pattern.Builder;

public interface AbstractBuilder {
	
	CursFitness build();
}
