package cts.Enache.IrinelMihaita.g1080.pattern.Chain;

public class EvaluareAccidentAntrenor extends EvaluareAccident{

	public EvaluareAccidentAntrenor(Accident accident) {
		super(accident);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void trimiteMaiDeparte() {
		// TODO Auto-generated method stub
		if(super.getAccident().getNivelAccident().ordinal() > 0) {
			
		}
		
	}

}
