package cts.Enache.IrinelMihaita.g1080.pattern.Chain;

public class FisaAccident {
    String numePersoana;
    int varsta;
    boolean esteConstient;
    boolean sePoateDeplasa;
    boolean areMembreRupte;
    boolean areRaniDeschise;
}
