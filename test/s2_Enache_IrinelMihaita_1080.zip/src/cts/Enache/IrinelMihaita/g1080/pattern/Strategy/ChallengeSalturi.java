package cts.Enache.IrinelMihaita.g1080.pattern.Strategy;

public class ChallengeSalturi implements IChallenge{

	@Override
	public void startExercitiu(int nrRepetitii) {
		// TODO Auto-generated method stub
		System.out.println("Pentru challenge se vor realiza " + nrRepetitii + " SALTURI.");

	}

}
