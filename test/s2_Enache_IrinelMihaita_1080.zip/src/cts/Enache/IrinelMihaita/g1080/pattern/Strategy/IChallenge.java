package cts.Enache.IrinelMihaita.g1080.pattern.Strategy;

public interface IChallenge {
    public void startExercitiu(int nrRepetitii);
}
